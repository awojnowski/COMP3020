//
//  DirectorsListAddView.h
//  MovieOrganizer
//
//  Created by Aaron Wojnowski on 2015-12-05.
//  Copyright © 2015 CS Boys. All rights reserved.
//

#import "ListAddView.h"

@interface DirectorsListAddView : ListAddView

@end
