//
//  HomeViewController.h
//  MovieOrganizer
//
//  Created by Kieran on 2015-11-30.
//  Copyright © 2015 CS Boys. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface HomeViewController : NSViewController

@end
