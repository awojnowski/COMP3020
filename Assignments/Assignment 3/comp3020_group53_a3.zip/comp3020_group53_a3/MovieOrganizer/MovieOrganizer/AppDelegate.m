//
//  AppDelegate.m
//  MovieOrganizer
//
//  Created by Aaron Wojnowski on 2015-11-29.
//  Copyright © 2015 CS Boys. All rights reserved.
//

#import "AppDelegate.h"
#import "CoreDataController.h"
#import "SeedDataLoader.h"

@interface AppDelegate ()

@end

@implementation AppDelegate



@end
