//
//  TagsListAddView.m
//  MovieOrganizer
//
//  Created by Aaron Wojnowski on 2015-12-05.
//  Copyright © 2015 CS Boys. All rights reserved.
//

#import "TagsListAddView.h"

@implementation TagsListAddView

-(NSString *)title {
    
    return @"Tags";
    
}

@end
